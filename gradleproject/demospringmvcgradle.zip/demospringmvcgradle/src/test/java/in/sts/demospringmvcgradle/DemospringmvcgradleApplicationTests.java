package in.sts.demospringmvcgradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemospringmvcgradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
